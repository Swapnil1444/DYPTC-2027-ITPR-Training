

public interface abc_interface {

	// void m1();
	void m2(int a);
	
	
	
}

