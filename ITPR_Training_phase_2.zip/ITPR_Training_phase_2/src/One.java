
public interface One {
 // void m2();

  void m1();
}
