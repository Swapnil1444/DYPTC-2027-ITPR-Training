import java.io.FileNotFoundException;
import java.io.FileReader;

public class Run {

	public static void main(String[] args) throws FileNotFoundException{
		
//		user_exption e=new user_exption();
//		e.m1();
		
		FileReader f=new FileReader("abc.txt");
      
	}

}
