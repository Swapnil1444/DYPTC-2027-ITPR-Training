
public class Bank extends RuntimeException {

	public Bank(String s) {
		super(s);

	}

}
